#include <Persona.hpp>

int main(int argc, char **argv)
{
	Persona	  *p1= new Persona(18);
	p1-> mostrar();
	Persona	  *p2= new Persona(19);
	p2-> mostrar();
	Persona	  *p3= new Persona(20);
	p3-> mostrar();
	Persona	  *p4= new Persona(21);
	p4-> mostrar();
	Persona	  *p5= new Persona(22);
	p5-> mostrar();
	Persona	  *p6= new Persona(23);
	p6-> mostrar();
	Persona	  *p7= new Persona(24);
	p7-> mostrar();
	Persona	  *p8= new Persona(25);
	p8-> mostrar();
	Persona	  *p9= new Persona(26);
	p9-> mostrar();
	Persona	  *p10= new Persona(27);
	p10-> mostrar();
	
	
	return 0;
}